import xbmc
import xbmcgui
import xbmcaddon
import os

ADDON        =  xbmcaddon.Addon(id='plugin.program.supremebuildswizard')
zip          =  ADDON.getSetting('zip')
d            =  xbmcgui.Dialog()

def CheckPath():
    path = xbmc.translatePath(os.path.join(zip,'testCBFolder'))
    print path
    try:
        os.makedirs(path)
        os.removedirs(path)
        d.ok('[COLOR=lime]SUCCESS[/COLOR]', 'Great news, the path you have chosen is writeable.', 'Caution, some builds are large', 'We recommend a minimum of 1GB free storage space in your chosen path location.')
    except:
        d.ok('[COLOR=red]CANNOT WRITE TO PATH[/COLOR]', 'Kodi cannot write to the path you\'ve chosen. Please click OK', 'in the settings menu to save the path then try again.', 'Some devices give false results, we recommend testing your backup path.')

if __name__ == '__main__':
    CheckPath()